/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useEffect, useRef, useState } from 'react';

// Basic PCM to Base64 encoder
const pcmToBase64 = (pcm: Float32Array): string => {
  const bytes = new Int16Array(pcm.length);
  for (let i = 0; i < pcm.length; i++) {
    bytes[i] = Math.max(-1, Math.min(1, pcm[i])) * 32767;
  }
  return btoa(String.fromCharCode(...new Uint8Array(bytes.buffer)));
};

// Play audio chunk
const playAudioChunk = (ctx: AudioContext, base64Audio: string) => {
  const binary = atob(base64Audio);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const buffer = ctx.createBuffer(1, bytes.length / 2, 24000);
  const data = buffer.getChannelData(0);
  const view = new Int16Array(bytes.buffer);
  for (let i = 0; i < view.length; i++) {
    data[i] = view[i] / 32768;
  }
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  source.connect(ctx.destination);
  source.start();
};

export default function App() {
  const [connected, setConnected] = useState(false);
  const [sourceLang, setSourceLang] = useState('km');
  const [targetLang, setTargetLang] = useState('en');
  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const [transcript, setTranscript] = useState<{original: string, translated: string}[]>([]);

  const processorRef = useRef<ScriptProcessorNode | null>(null);

  const stopTranslation = () => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    if (processorRef.current) {
        processorRef.current.disconnect();
        processorRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      inputAudioCtxRef.current.close();
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      outputAudioCtxRef.current.close();
      outputAudioCtxRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    setConnected(false);
  };

  const startTranslation = async (source = sourceLang, target = targetLang) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      const wsProtocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${wsProtocol}//${location.host}/live?source=${source}&target=${target}`);
      wsRef.current = ws;

      const inputAudioCtx = new AudioContext({ sampleRate: 16000 });
      const outputAudioCtx = new AudioContext({ sampleRate: 24000 });
      inputAudioCtxRef.current = inputAudioCtx;
      outputAudioCtxRef.current = outputAudioCtx;

      const inputSource = inputAudioCtx.createMediaStreamSource(stream);
      const processor = inputAudioCtx.createScriptProcessor(1024, 1, 1);
      processorRef.current = processor;
      inputSource.connect(processor);
      processor.connect(inputAudioCtx.destination);

      processor.onaudioprocess = (e) => {
        if (ws.readyState === WebSocket.OPEN) {
          const base64 = pcmToBase64(e.inputBuffer.getChannelData(0));
          ws.send(JSON.stringify({ audio: base64 }));
        }
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.audio) playAudioChunk(outputAudioCtx, msg.audio);
        if (msg.inputTranscript || msg.outputTranscript) {
          setTranscript(prev => [
            ...prev, 
            { original: msg.inputTranscript || "", translated: msg.outputTranscript || "" }
          ]);
        }
      };

      ws.onopen = () => setConnected(true);
      ws.onclose = () => setConnected(false);
    } catch (err) {
      console.error("Error starting translation", err);
    }
  };

  const changeLanguages = async (newSource: string, newTarget: string) => {
    setSourceLang(newSource);
    setTargetLang(newTarget);
    if (connected) {
      stopTranslation();
      setTimeout(() => {
        startTranslation(newSource, newTarget);
      }, 300);
    }
  };

  return (
    <div className="w-full h-screen bg-[#050505] text-[#E0D8D0] font-khmer flex flex-col overflow-hidden animate-fade-in">
      {/* ក្បាលទំព័រ */}
      <header className="h-20 border-b border-[#2A2A2A] px-10 flex items-center justify-between bg-[#0A0A0A]">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-amber-900/20">
            <span className="text-black font-moul text-2xl">ខ</span>
          </div>
          <div>
            <h1 className="text-2xl font-moul tracking-wide text-amber-500">ខេ-សមកាលកម្ម</h1>
            <p className="text-[10px] uppercase opacity-50 tracking-[0.2em]">អ្នកបកប្រែភាសាបន្តផ្ទាល់</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-3 bg-[#151515] px-4 py-2 rounded-full border border-[#2A2A2A]">
            <div className={`w-2.5 h-2.5 rounded-full ${connected ? 'bg-green-500 animate-pulse' : 'bg-red-600'}`}></div>
            <span className="text-xs font-bold uppercase tracking-widest">{connected ? "កំពុងដំណើរការ" : "ផ្ដាច់ការតភ្ជាប់"}</span>
          </div>
          <div className="h-6 w-[1px] bg-[#2A2A2A]"></div>
          <div className="flex items-center space-x-2 text-sm font-bold text-amber-500">
            <span className="bg-amber-500/10 px-3 py-1 rounded-md border border-amber-500/20">
              {sourceLang.toUpperCase()} ➔ {targetLang.toUpperCase()}
            </span>
          </div>
        </div>
      </header>

      {/* តំបន់មាតិកាចម្បង */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* បង្ហាញការបកប្រែធំៗ */}
        <section className="flex-1 relative bg-[#070707] flex flex-col items-center justify-between p-12">
          {/* កាតព័ត៌មានស្ថានភាពប្រព័ន្ធ */}
          <div className="w-full flex justify-between items-start">
            <div className="bg-black/60 backdrop-blur-md px-5 py-4 rounded-2xl border border-white/5 shadow-2xl">
              <p className="text-[10px] uppercase font-bold tracking-[0.2em] opacity-40 mb-2">ស្ថានភាពប្រព័ន្ធ</p>
              <div className="flex items-center space-x-2">
                <div className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-amber-500 animate-pulse' : 'bg-gray-600'}`}></div>
                <p className="text-sm font-medium text-amber-500">{connected ? "ប្រព័ន្ធដំណើរការសមកាលកម្ម" : "រង់ចាំការតភ្ជាប់"}</p>
              </div>
            </div>

            {/* ប៊ូតុងជ្រើសរើសទិសដៅបកប្រែ (Translation Direction Selector) */}
            <div className="flex items-center space-x-2">
              <select
                className="bg-[#121212] text-white text-xs font-bold px-4 py-2 rounded-full border border-[#2A2A2A] shadow-xl appearance-none pr-8 cursor-pointer hover:border-amber-600 transition-all"
                value={sourceLang}
                onChange={(e) => changeLanguages(e.target.value, targetLang)}
              >
                <option value="km">ខ្មែរ</option>
                <option value="en">អង់គ្លេស</option>
                <option value="zh">ចិន</option>
                <option value="vi">វៀតណាម</option>
                <option value="ja">ជប៉ុន</option>
                <option value="ko">កូរ៉េ</option>
                <option value="th">ថៃ</option>
              </select>
              
              <button 
                onClick={() => changeLanguages(targetLang, sourceLang)}
                className="p-2 rounded-full bg-[#1A1A1A] border border-[#2A2A2A] text-white/50 hover:text-amber-500 hover:border-amber-600 transition-all"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                </svg>
              </button>

              <select
                className="bg-[#121212] text-white text-xs font-bold px-4 py-2 rounded-full border border-[#2A2A2A] shadow-xl appearance-none pr-8 cursor-pointer hover:border-amber-600 transition-all"
                value={targetLang}
                onChange={(e) => changeLanguages(sourceLang, e.target.value)}
              >
                <option value="km">ខ្មែរ</option>
                <option value="en">អង់គ្លេស</option>
                <option value="zh">ចិន</option>
                <option value="vi">វៀតណាម</option>
                <option value="ja">ជប៉ុន</option>
                <option value="ko">កូរ៉េ</option>
                <option value="th">ថៃ</option>
              </select>
            </div>
          </div>

          {/* មាតិកាបកប្រែកណ្ដាល */}
          <div className="w-full max-w-4xl flex flex-col items-center space-y-12 my-auto">
            {connected ? (
              <div className="w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 text-center">
                <div className="inline-block bg-amber-500/5 border border-amber-500/10 px-6 py-2 rounded-full mb-4">
                  <p className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.3em]">
                    ទិសដៅបកប្រែ៖ {sourceLang.toUpperCase()} ➔ {targetLang.toUpperCase()}
                  </p>
                </div>
                <h2 className="text-5xl md:text-6xl font-khmer font-bold leading-[1.6] text-white drop-shadow-2xl px-4 min-h-[120px] flex items-center justify-center">
                  {transcript.length > 0 ? transcript[transcript.length - 1].translated : "(កំពុងរង់ចាំការនិយាយ...)"}
                </h2>
                
                <div className="pt-6">
                  <button 
                    onClick={stopTranslation} 
                    className="group px-10 py-4 bg-red-600/10 border border-red-500/50 text-red-500 hover:bg-red-600 hover:text-white transition-all font-bold uppercase tracking-[0.2em] rounded-full shadow-xl text-sm flex items-center space-x-3 mx-auto"
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
                    <span>បញ្ឈប់ការបកប្រែ</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-8 max-w-lg py-12">
                <div className="w-24 h-24 bg-amber-600/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-amber-500/20 shadow-inner">
                  <svg className="w-10 h-10 text-amber-500 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m8 0h-3m4-10a3 3 0 00-3-3m0 0a3 3 0 00-3 3m3-3v3m0 0l-3 3m3-3l3 3" />
                  </svg>
                </div>
                <h2 className="text-3xl font-khmer font-bold text-white leading-relaxed">ប្រព័ន្ធរួចរាល់សម្រាប់ការបកប្រែ</h2>
                <p className="text-[#E0D8D0]/60 leading-relaxed font-light text-sm">សូមជ្រើសរើសរបៀបបកប្រែខាងលើ រួចចុចប៊ូតុងខាងក្រោមដើម្បីចាប់ផ្ដើមស្ដាប់ និងបកប្រែរាល់ពាក្យសម្ដីភ្លាមៗជាមួយសំឡេងត្រឡប់មកវិញ។</p>
                <button 
                  onClick={() => startTranslation()} 
                  className="group px-12 py-5 bg-amber-600 text-black hover:bg-amber-500 hover:scale-105 active:scale-95 transition-all font-bold uppercase tracking-[0.2em] rounded-full shadow-2xl shadow-amber-900/40 text-sm"
                >
                  ចាប់ផ្ដើមបកប្រែផ្ទាល់
                </button>
              </div>
            )}
          </div>

          <div className="text-xs text-white/20 uppercase tracking-[0.2em]">សហការជាមួយបច្ចេកវិទ្យាបញ្ញាសិប្បនិម្មិតកម្រិតខ្ពស់</div>
        </section>

        {/* របារចំហៀង៖ ប្រវត្តិអត្ថបទបកប្រែ */}
        <aside className="w-[450px] border-l border-[#2A2A2A] bg-[#0A0A0A] flex flex-col p-10 space-y-10">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] uppercase tracking-[0.3em] opacity-40 font-bold">ប្រវត្តិការបកប្រែ</h3>
              <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-white/40 uppercase tracking-widest">{transcript.length} ឃ្លា</span>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-12 pr-4 custom-scrollbar">
                {transcript.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center opacity-20 space-y-4">
                    <div className="w-12 h-[1px] bg-white"></div>
                    <p className="text-xs uppercase tracking-widest text-center">មិនទាន់មានទិន្នន័យ</p>
                  </div>
                ) : (
                  transcript.map((item, i) => (
                    <div key={i} className="group space-y-4 pb-8 border-b border-white/5 last:border-0 last:pb-0 animate-in fade-in duration-500">
                        <div className="flex items-center space-x-2 justify-between">
                           <div className="flex items-center space-x-2">
                             <div className="w-1 h-1 rounded-full bg-amber-500"></div>
                             <p className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-bold">លទ្ធផលបកប្រែ</p>
                           </div>
                           {item.original && (
                             <span className="text-[10px] text-white/20 italic font-light truncate max-w-[200px]" title={item.original}>
                               {item.original}
                             </span>
                           )}
                        </div>
                        <p className="text-xl text-[#E0D8D0] font-khmer font-medium leading-[1.8] group-hover:text-amber-100 transition-colors">
                          {item.translated}
                        </p>
                    </div>
                  ))
                )}
                <div ref={(el) => el?.scrollIntoView({ behavior: 'smooth' })} />
            </div>
        </aside>
      </main>

      {/* ផ្នែកខាងក្រោម */}
      <footer className="h-20 bg-[#0A0A0A] border-t border-[#2A2A2A] px-10 flex items-center justify-between font-khmer">
         <p className="text-[10px] text-white/20 uppercase tracking-[0.4em] font-medium">រក្សាសិទ្ធិគ្រប់យ៉ាង © ២០២៦</p>
         <button className="px-10 py-3 bg-transparent border border-white/10 text-white/60 hover:border-amber-600/50 hover:text-amber-500 transition-all text-[10px] font-bold uppercase tracking-[0.2em] rounded-full">
            ការកំណត់ប្រព័ន្ធ
          </button>
      </footer>
    </div>

  );
}

