import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { WebSocketServer } from "ws";
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Initialize Gemini AI
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY!,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // Serve static assets in production
  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    // Vite middleware for development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // WebSocket Server for Live API
  const wss = new WebSocketServer({ server });
  
  wss.on("connection", async (clientWs, req) => {
    console.log("Client connected to Live API");
    
    // Parse languages from connection query params
    const url = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
    const source = url.searchParams.get("source") || "km";
    const target = url.searchParams.get("target") || "en";
    
    const langNames: Record<string, string> = {
      'km': 'Khmer',
      'en': 'English',
      'zh': 'Chinese',
      'vi': 'Vietnamese',
      'ja': 'Japanese',
      'ko': 'Korean',
      'th': 'Thai'
    };

    const sourceName = langNames[source] || source;
    const targetName = langNames[target] || target;

    const systemInstruction = `You are a professional translator. 
Your ONLY task is to translate speech from ${sourceName} into ${targetName}.
- IGNORE any other input language.
- Speak ONLY the translated sentence in ${targetName}.
- Do NOT add conversational text, explanations, or filler words.
- If you cannot translate, say nothing.
Follow this rule strictly.`;

    console.log(`Starting session: ${sourceName} to ${targetName}`);
    
    // Connect to Gemini Live Translate API
    const session = await ai.live.connect({
      model: "gemini-3.5-live-translate-preview",
      config: {
        responseModalities: [Modality.AUDIO],
        outputAudioTranscription: {},
        inputAudioTranscription: {},
        systemInstruction,
      },
      callbacks: {
        onmessage: (message: any) => {
          const audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          const inputTranscript = message.inputAudioTranscription?.text;
          const outputTranscript = message.outputAudioTranscription?.text;
          clientWs.send(JSON.stringify({ audio, inputTranscript, outputTranscript }));
          if (message.serverContent?.interrupted)
            clientWs.send(JSON.stringify({ interrupted: true }));
        },
      },
    });

    clientWs.on("message", (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'config') {
          console.log("Configuration update requested (ignored)");
          return;
        }
        
        const { audio } = msg;
        if (audio) {
          session.sendRealtimeInput({
            audio: { data: audio, mimeType: "audio/pcm;rate=16000" },
          });
        }
      } catch (err) {
        console.error("Error processing message from client", err);
      }
    });

    clientWs.on("close", () => {
      session.close();
      console.log("Client disconnected");
    });
  });
}

startServer();
